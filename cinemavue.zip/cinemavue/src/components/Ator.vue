<template>
 <v-container>
   <h1>{{ this.ator.nome }}</h1>
   <v-data-table
            :headers="headers"
            :items="filmes"
            class="elevation-1"
        >
            <template v-slot:no-data>
                <v-alert :value="true" color="error" icon="warning">
                    Não foi possivel apresentar uma lista dos filmes...
                </v-alert>
            </template>

            <template v-slot:items="props">
                <tr @click="rowClicked(props.item)">
                    <td class="subheading">{{props.item.f.split('#')[1]}}</td>
                    <td class="subheading">{{props.item.ftit}}</td>
                </tr>
            </template>
        </v-data-table>
 </v-container>
</template>

<script>
  import axios from 'axios'
  const lhost="http://cinema.di.uminho.pt"

  export default{
      props: ["idAtor"],
      data: () =>({
          ator: {},
          headers:[
              
              {text: 'Identificador',sortable: false, value: 'id', class: 'title'},
              {text: 'Título',sortable: true, value: 'tit', class: 'title'}
          ],
          filmes: []
      }),

      mounted: async function(){
          try{
              var response = await axios.get(lhost + '/atores/'+ this.idAtor);
              this.ator= response.data[0];
              response = await axios.get(lhost + '/atores/'+ this.idAtor+'/filmes')
              this.filmes = response.data;
              console.log(this.filmes)
          }catch(e){
              return(e);
          }
      }
  }
</script>

<style>