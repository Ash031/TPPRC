<template>
  <Filmes />
</template>

<script>
  import Filmes from '@/components/Filmes'

  export default {
    components: {
      Filmes
    }
  }
</script>
