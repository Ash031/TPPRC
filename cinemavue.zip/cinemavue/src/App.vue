<template>
  <v-app>
    <v-content>
        <router-view/>
    </v-content>
  </v-app>
</template>
						
<script>
    export default {
        name: 'App',
        /*
        components:{
          HelloWorld
        },
        //Todas as variaveis necessarias para manipular informação (aceder com this.filmes, p.e)
        data(){
          return{
            filmes:[]
          }
        }
        //mounted: function(){//axios a ir buscar a informação}- serve para arrancar esta função quando a aplicação e corrida
  */}
</script>
