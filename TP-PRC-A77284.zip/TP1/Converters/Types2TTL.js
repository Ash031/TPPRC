const jsonfile = require('jsonfile')
const file = 'TypeDex.json'
function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
jsonfile.readFile("JSONS/"+file)
  .then(obj => {
      console.log("\n### Type List ###\n");
      for(var i=0; i<obj.length; i++){
        	var type = "";
			type += ":T_" + obj[i].name.replace(/\W/,"")+ " a owl:NamedIndividual, :Type;\n";
			
			var damages = obj[i].damage_relations;

			damages.double_damage_to.forEach(t => {
				type+="\t:doubleDamageTo :T_"+t.name+";\n";
			});
			damages.double_damage_from.forEach(t => {
				type+="\t:doubleDamageFrom :T_"+t.name+";\n";
			});

			damages.half_damage_to.forEach(t => {
				type+="\t:halfDamageTo :T_"+t.name+";\n";
			});
			damages.half_damage_from.forEach(t => {
				type+="\t:halfDamageFrom :T_"+t.name+";\n";
			});

			damages.no_damage_to.forEach(t => {
				type+="\t:noDamageTo :T_"+t.name+";\n";
			});
			damages.no_damage_from.forEach(t => {
				type+="\t:noDamageFrom :T_"+t.name+";\n";
			});

          	type += "\t:generationAdded \"" + obj[i].generation.name.split("-")[1].toUpperCase()+"\";\n";
            
          	type += "\t:name \""+capitalize_Words(obj[i].name)+"\".\n";
  
          	console.log(type);
        }
  })
  .catch(error => console.error(error))