const jsonfile = require('jsonfile')
const file = 'Locations.json'
function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
jsonfile.readFile("JSONS/"+file)
  .then(obj => {
      console.log("\n### Locations List ###\n");
      for(var i=0; i<obj.length; i++){
        	var area = "";
          	area += ":L_" + obj[i].id+ " a owl:NamedIndividual, :Location;\n";

						if(obj[i].region)area += ":fromRegion :R_"+obj[i].region.name+";\n";
						area +=":name \""+capitalize_Words(obj[i].name)+"\".";
  
          	console.log(area);
        }
  })
  .catch(error => console.error(error))