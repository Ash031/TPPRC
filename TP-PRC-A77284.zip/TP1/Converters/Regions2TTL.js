const jsonfile = require('jsonfile')
const file = 'Regions.json'

function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

jsonfile.readFile("JSONS/"+file)
  	.then(obj => {
      	console.log("\n### Region List ###\n");
      	var games = []
      	for(var i=0; i<obj.length; i++){
        	var region = "";
          	region += ":R_" + obj[i].name+ " a owl:NamedIndividual, :Region;\n";
            obj[i].version_groups.forEach(e=>{
                if(games.indexOf(e.name) == -1){
        	        games.push(e.name);
                }
				region += ":fromGame :G_"+e.name+";\n";
            })
			region +=":name \""+capitalize_Words(obj[i].name)+"\".";
  
          	console.log(region);
        }
		games.forEach(e=>{
			console.log(":G_"+e+" a owl:NamesIndividual, :Game; :name \""+capitalize_Words(e)+"\".");
		})
  	})
  	.catch(error => console.error(error))

