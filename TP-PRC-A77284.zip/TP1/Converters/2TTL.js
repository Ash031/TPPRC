const jsonfile = require('jsonfile')
const file = 'Pokedex.json'
function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

jsonfile.readFile("JSONS/"+file)
  .then(obj => {
      console.log("\n### Pokémon List ###\n");
      for(var i=0; i<obj.length; i++){
          var pokemon = "";
          pokemon += ":P_" + obj[i].id+ " a owl:NamedIndividual, :Pokemon;\n";
          obj[i].types.forEach(typing => {
            type = typing.type.name
            pokemon += "\t:hasType :T_" + type + ";\n";
          });

          obj[i].stats.forEach(status=>{
            pokemon+="\t:"+status.stat.name+" "+status.base_stat+";\n";
          })

          obj[i].abilities.forEach(ab=>{
            abName = ab.ability.name
            pokemon += "\t:hasAbility :A_"+abName+";\n";
          })
          existe = []
          obj[i].moves.forEach(move=>{
            moveName = move.move.name.replace(/\W/g,"")
            if(existe.indexOf(moveName)==-1){
              pokemon += "\t:learnsMove :M_"+moveName+";\n";
            }
          })
          pokemon += "\t:name \"" + capitalize_Words(obj[i].name) + "\";\n";
          pokemon += "\t:height " + obj[i].height + ";\n";
          pokemon += "\t:weight " + obj[i].weight + ";\n";
          pokemon += "\t:id " + obj[i].id + ".\n";
 
          console.log(pokemon);
      }
  })
  .catch(error => console.error(error))

