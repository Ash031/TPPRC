const jsonfile = require('jsonfile')
const file = 'AbilityDex.json'
function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
jsonfile.readFile("JSONS/"+file)
  .then(obj => {
      console.log("\n### Ability List ###\n");
      for(var i=0; i<obj.length; i++){
        	var ability = "";
          	ability += ":A_" + obj[i].name.replace(/\W/,"")+ " a owl:NamedIndividual, :Ability;\n";

			ability += "\t:effect \""+capitalize_Words(obj[i].effect_entries[0].short_effect)+"\";\n"

          	ability += "\t:id "+obj[i].id+";\n"

          	ability += "\t:generationAdded \"" + obj[i].generation.name.split("-")[1].toUpperCase()+"\";\n";
            
          	ability += "\t:name \""+capitalize_Words(obj[i].name)+"\".\n";
  
          	console.log(ability);
        }
  })
  .catch(error => console.error(error))