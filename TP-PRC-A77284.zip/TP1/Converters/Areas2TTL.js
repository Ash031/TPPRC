const jsonfile = require('jsonfile')
const file = 'Areas.json'
function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
jsonfile.readFile("JSONS/"+file)
  .then(obj => {
      console.log("\n### Areas List ###\n");
      for(var i=0; i<obj.length; i++){
        	var area = "";
          	area += ":Area_" + obj[i].id+ " a owl:NamedIndividual, :Area;\n";

						obj[i].pokemon_encounters.forEach(e => {
							area += "\t:homeTo :P_"+e.pokemon.url.split("/")[6]+";\n";
						});
						area +="\t:isOn :L_"+obj[i].location.url.split("/")[6]+";\n";
						area +="\t:name \""+capitalize_Words(obj[i].name)+"\".\n";
  
          	console.log(area);
        }
  })
  .catch(error => console.error(error))