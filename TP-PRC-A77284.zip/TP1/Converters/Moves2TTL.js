const jsonfile = require('jsonfile')
const file = 'MoveDex.json'
function capitalize_Words(str){
 return str.replace(/[a-zA-Z0-9]+[ -_]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
jsonfile.readFile("JSONS/"+file)
	.then(obj => {
		console.log("\n### Move List ###\n");
		for(var i=0; i<obj.length; i++){
				var move = "";
				var moveName = obj[i].name.replace(/\W/g,"")
				move += ":M_" + moveName+ " a owl:NamedIndividual, :Move;\n";
				if(obj[i].accuracy!=undefined && obj[i].accuracy!=null) move += "\t:accuracy "+obj[i].accuracy+";\n"
				if(obj[i].effect_chance!=undefined && obj[i].effect_chance!=null) {
					move += "\t:effectChance "+obj[i].effect_chance+";\n"
				}
				move += "\t:attackType \""+obj[i].damage_class.name+"\";\n"
				if(obj[i].power!=undefined && obj[i].power!=null)move += "\t:attackPower "+obj[i].power+";\n"
				if(obj[i].pp!=undefined && obj[i].pp!=null)move += "\t:attackPP "+obj[i].pp+";\n"
				if(obj[i].priority!=undefined && obj[i].priority!=null)move += "\t:attackPriority "+obj[i].priority+";\n"

				move += "\t:hasType :T_"+obj[i].type.name+";\n"

				move += "\t:generationAdded \"" + obj[i].generation.name.split("-")[1].toUpperCase()+"\";\n";
					
				move += "\t:name \""+capitalize_Words(obj[i].name)+"\".\n";
 
				console.log(move);
			}
 
	})
	.catch(error => console.error(error))