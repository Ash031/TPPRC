const Pokemon = module.exports;
var axios = require('axios')
async function execQuery(q){
    try{
        var encoded = encodeURIComponent(q);
        var response = await axios.get("http://localhost:7200/repositories/Pokedex?query="+encoded);
        return response.data;
    }
    catch(e){
        return e;
    }
}

Pokemon.listPokemons = async ()=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name ?type ?type2 ?id where{	
        ?s a :Pokemon;
           :id ?id;
           :name ?name;
           :hasType1 ?t.
    ?t :name ?type.
       OPTIONAL {
            ?s :hasType2 ?t2.
        	?t2 :name ?type2
       }
}`;
    var d = await execQuery(query);
    return d;
} 

Pokemon.getPokemon = async (id)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct * where{	
        ?s a :Pokemon;
           :id `+id+`;
           :name ?name;
           :defense ?d;
           :attack ?a;
           :hp ?hp;
           :specialattack ?sa;
           :specialdefense ?sd;
           :speed ?speed;
           :height ?height;
           :weight ?weight;
           :hasType1 ?type1.
        ?type1 :name ?nameType1.
        OPTIONAL{
            ?s :hasType2 ?type2.
            ?type2 :name ?nameType2.
        }
    } `;
    var d = await execQuery(query);
    return d;
} 

Pokemon.getAbility = async (id)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?eff ?name ?gen where{	
        ?s a :Ability;
           :id `+id+`;
           :effect ?eff;
           :name ?name;
           :generationAdded ?gen;
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getTypePokemons = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?id ?name where{	
        ?s a :Type;
           :name "`+name+`";
        OPTIONAL{
        	?p :hasType1 ?s;
            	:name ?name;
             	:id ?id;
    	}
        OPTIONAL{
        	?p :hasType2 ?s;
            	:name ?name;
             	:id ?id;
    	}
}  `;
    var d = await execQuery(query);
    return d;
} 

Pokemon.getAbilityPokes = async (id)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?id ?name where{	
        ?s a :Ability;
           :id `+id+`.
    ?pok :hasAbility ?s;
    	 :name ?name;
    	 :id ?id.
    } `;
    var d = await execQuery(query);
    return d;
} 

Pokemon.getTypeDoubleTo = async (type)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name where{	
        ?s a :Type;
           :name "`+type+`";
           :doubleDamageTo ?type.
    	?type :name ?name
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getTypeDoubleFrom = async (type)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name where{	
        ?s a :Type;
           :name "`+type+`";
           :doubleDamageFrom ?type.
    	?type :name ?name
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getTypehalfTo = async (type)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name where{	
        ?s a :Type;
           :name "`+type+`";
           :halfDamageTo ?type.
    	?type :name ?name
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getTypehalfFrom = async (type)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name where{	
        ?s a :Type;
           :name "`+type+`";
           :halfDamageFrom ?type.
    	?type :name ?name
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getTypenoDamageTo = async (type)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name where{	
        ?s a :Type;
           :name "`+type+`";
           :noDamageTo ?type.
    	?type :name ?name
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getTypenoDamageFrom = async (type)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name where{	
        ?s a :Type;
           :name "`+type+`";
           :noDamageFrom ?type.
    	?type :name ?name
    } `;
    var d = await execQuery(query);
    return d;
} 

Pokemon.getPokemonMoves = async (id)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?typeName ?at ?power ?name where{	
        ?s a :Pokemon;
           :id `+id+`;
           :learnsMove ?move.
        ?move :name ?name;
           :hasType ?mt;
           :attackType ?at.
        ?mt :name ?typeName.
        OPTIONAL {
            ?move :attackPower ?power
        }
    } `;
    var d = await execQuery(query);
    return d;
} 

Pokemon.getPokemonAbilities = async (id)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?id ?name where{	
        ?s a :Pokemon;
           :id `+id+`;
           :hasAbility ?ability.
    ?ability :name ?name;
             :id ?id
    }`;
    var d = await execQuery(query);
    return d;
} 
Pokemon.listMoves = async ()=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct (count (?p) as ?n) ?name  ?atype ?typeName where { 
        ?s a :Move;
            :name ?name;
             :attackType ?atype;
             :hasType ?type.
        ?p :learnsMove ?s.
        ?type :name ?typeName.
    } GROUP BY ?s ?name ?typeName ?atype`;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getMove = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?pp ?at ?power ?gen ?acc ?typeName ?chance where{	
        ?s a :Move;
           :name "`+name+`";
    		:attackPP ?pp;
      		:attackPriority ?ap;
        	:hasType ?type;
         	:generationAdded ?gen;
      		:attackType ?at.
    	?type :name ?typeName;
        OPTIONAL {?s :attackPower ?power;}
        OPTIONAL {?s :effectChance ?chance;}
        OPTIONAL {?s :accuracy ?acc;}
    } 
		 `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getRoutePokemons = async (id)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select ?name ?reg where {
        ?poke :id `+id+`.
        ?a :homeTo ?poke;
           :name ?name.
        OPTIONAL{
            ?a :isOn ?l.
            ?l :fromRegion ?r.
            ?r :name ?reg.
        }
             
    }
    `
    var d = await execQuery(query);
    return d;
}

Pokemon.getRoute = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select ?locName ?reg where {
        ?a a :Area;
           :name "`+name+`".
        OPTIONAL{
            ?a :isOn ?l.
            ?l :fromRegion ?r;
               :name ?locName.
            ?r :name ?reg.
        }
             
    }    
    `
    var d = await execQuery(query);
    return d;
}
Pokemon.getRouteMons = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select ?name ?id where {
        ?a a :Area;
           :name "`+name+`";
           :homeTo ?p.
        ?p :name ?name;
           :id ?id;
             
    }
    `
    var d = await execQuery(query);
    return d;
}
Pokemon.getMovePokemons = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select ?id ?name where {
        ?s a :Move;
           :name \"`+name+`\";
           :isLearntBy ?poke.
        ?poke :id ?id;
              :name ?name.
    }`;
    var d = await execQuery(query);
    return d;
} 
Pokemon.listAbilities = async ()=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct * where{	
        ?s a :Ability;
           ?o ?p;
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.listTypes = async ()=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct * where{	
        ?s a :Type;
           ?o ?p;
    } `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getRegionsGames = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select ?name where {
        ?a a :Region;
           :fromGame ?game;
           :name "`+name+`".
        ?game :name ?name
    }
    `;
    var d = await execQuery(query);
    return d;
} 
Pokemon.getRegionPokemon = async (name)=>{
    const query = `PREFIX : <urn:absolute:PokedexRedux#>
    select distinct ?name ?id where { 
        ?s a :Region;
            :name "`+name+`".
        ?l :fromRegion ?s.
        ?a :isOn ?l;
           :homeTo ?pokemon.
        ?pokemon :name ?name;
                 :id ?id.
    }
    
    `;
    var d = await execQuery(query);
    return d;
} 

