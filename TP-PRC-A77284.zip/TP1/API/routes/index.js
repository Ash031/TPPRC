var express = require('express');
var router = express.Router();
var axios = require('axios');
var Pokemon = require('../Controllers/Pokemon')
/* GET home page. */
router.get('/pokemons',async function(req, res) {
  var data = await Pokemon.listPokemons();
  res.jsonp(data);
});
router.get('/types/pokemons/:name',async function(req, res) {
  var data = await Pokemon.getTypePokemons(req.params.name);
  res.jsonp(data);
});
router.get('/pokemons/area/:id',async function(req, res) {
  var data = await Pokemon.getRoutePokemons(req.params.id);
  res.jsonp(data);  
});
router.get('/pokemons/:id',async function(req, res) {
  var data = await Pokemon.getPokemon(req.params.id);
  res.jsonp(data);
});
router.get('/moves',async function(req, res) {
  var data = await Pokemon.listMoves();
  res.jsonp(data);
});
router.get('/moves/isLearntBy/:name',async function(req, res) {
  var data = await Pokemon.getMovePokemons(req.params.name);
  res.jsonp(data);
});
router.get('/moves/:name',async function(req, res) {
  var data = await Pokemon.getMove(req.params.name);
  res.jsonp(data);
});
router.get('/moves/pokemon/:id',async function(req, res) {
  var data = await Pokemon.getPokemonMoves(req.params.id);
  res.jsonp(data);
});
router.get('/abilities',async function(req, res) {
  var data = await Pokemon.listAbilities();
  res.jsonp(data);
});
router.get('/abilities/pokemon/:id',async function(req, res) {
  var data = await Pokemon.getPokemonAbilities(req.params.id);
  res.jsonp(data);
});
router.get('/abilities/:id',async function(req, res) {
  var data = await Pokemon.getAbility(req.params.id);
  res.jsonp(data);
});
router.get('/abilities/allpokemons/:id',async function(req, res) {
  var data = await Pokemon.getAbilityPokes(req.params.id);
  res.jsonp(data);
});
router.get('/types',async function(req, res) {
  var data = await Pokemon.listTypes();
  res.jsonp(data);
});
router.get('/types/doubleto/:name',async function(req, res) {
  var data = await Pokemon.getTypeDoubleTo(req.params.name);
  res.jsonp(data);
});
router.get('/types/doublefrom/:name',async function(req, res) {
  var data = await Pokemon.getTypeDoubleFrom(req.params.name);
  res.jsonp(data);
});
router.get('/types/halfto/:name',async function(req, res) {
  var data = await Pokemon.getTypehalfTo(req.params.name);
  res.jsonp(data);
});
router.get('/types/halffrom/:name',async function(req, res) {
  var data = await Pokemon.getTypehalfFrom(req.params.name);
  res.jsonp(data);
});
router.get('/types/imuneto/:name',async function(req, res) {
  var data = await Pokemon.getTypenoDamageTo(req.params.name);
  res.jsonp(data);
});
router.get('/types/imunefrom/:name',async function(req, res) {
  var data = await Pokemon.getTypenoDamageFrom(req.params.name);
  res.jsonp(data);
});
router.get('/area/:name',async function(req, res) {
  var data = await Pokemon.getRoute(req.params.name);
  res.jsonp(data);
});
router.get('/area/pokemons/:name',async function(req, res) {
  var data = await Pokemon.getRouteMons(req.params.name);
  res.jsonp(data);
});
router.get('/region/:name',async function(req, res) {
  var data = await Pokemon.getRegionsGames(req.params.name);
  res.jsonp(data);
});
router.get('/region/pokemons/:name',async function(req, res) {
  var data = await Pokemon.getRegionPokemon(req.params.name);
  res.jsonp(data);
});

module.exports = router;