<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Moves />
  </v-container>
</template>

<script>
import Moves from '@/components/Moves'
import HeaderBar from '@/components/HeaderBar'

export default {
  components: {
    Moves,
    HeaderBar
  }
}
</script>
