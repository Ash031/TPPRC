<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <RegionGames :regionName="$route.params.name"/>
    <RegionPokemons :regionName="$route.params.name"/>
  </v-container>
</template>

<script>
import RegionGames from '@/components/RegionGames'
import HeaderBar from '@/components/HeaderBar'
import RegionPokemons from '@/components/RegionPokemons'
export default {
  components: {
    RegionGames,
    RegionPokemons,
    HeaderBar
  }
}
</script>
