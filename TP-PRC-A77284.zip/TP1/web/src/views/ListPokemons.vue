<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Pokemons />
  </v-container>
</template>

<script>
import Pokemons from '@/components/Pokemons'
import HeaderBar from '@/components/HeaderBar'

export default {
  components: {
    Pokemons,
    HeaderBar
  }
}
</script>
