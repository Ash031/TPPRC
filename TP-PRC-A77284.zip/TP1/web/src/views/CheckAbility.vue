<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Ability style="background-color:white" :idAb="$route.params.id"/>
    <AbilityPoke :idAb="$route.params.id"/>
  </v-container>
</template>

<script>
import Ability from '@/components/Ability'
import AbilityPoke from '@/components/AbilityPoke'
import HeaderBar from '@/components/HeaderBar'
export default {
  components: {
    Ability,
    AbilityPoke,
    HeaderBar
  }
}
</script>
