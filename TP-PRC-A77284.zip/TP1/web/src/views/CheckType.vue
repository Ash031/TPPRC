<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Type :typeName="$route.params.name"/>
  </v-container>
</template>

<script>
import Type from '@/components/Type'
import HeaderBar from '@/components/HeaderBar'
export default {
  components: {
    Type,
    HeaderBar
  }
}
</script>
