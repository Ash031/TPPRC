<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Move style="background-color:white" :moveName="$route.params.name"/>
    <MovesPoke :moveName="$route.params.name"/>
  </v-container>
</template>

<script>
import Move from '@/components/Move'
import MovesPoke from '@/components/MovesPoke'
import HeaderBar from '@/components/HeaderBar'
export default {
  components: {
    Move,
    MovesPoke,
    HeaderBar
  }
}
</script>
