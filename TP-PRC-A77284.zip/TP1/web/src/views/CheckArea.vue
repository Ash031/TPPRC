<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Area style="background-color:white" :areaName="$route.params.name"/>
    <AreasPoke :areaName="$route.params.name"/>
  </v-container>
</template>

<script>
import Area from '@/components/Area'
import AreasPoke from '@/components/AreasPoke'
import HeaderBar from '@/components/HeaderBar'
export default {
  components: {
    Area,
    AreasPoke,
    HeaderBar
  }
}
</script>
