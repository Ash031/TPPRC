<template>
  <v-container style="background-color:white">
    <HeaderBar />
    <Pokemon style="background-color:white" :idPoke="$route.params.id"/>
    <PokeAbilities style="background-color:white" :idPoke="$route.params.id"/>
    <PokeMoves :idPoke="$route.params.id"/>
    <PokeAreas :idPoke="$route.params.id"/>
  </v-container>
</template>

<script>
import Pokemon from '@/components/Pokemon'
import PokeMoves from '@/components/PokeMoves'
import PokeAbilities from '@/components/PokeAbilities'
import HeaderBar from '@/components/HeaderBar'
import PokeAreas from '@/components/PokeAreas'
export default {
  components: {
    PokeMoves,
    PokeAbilities,
    Pokemon,
    PokeAreas,
    HeaderBar
  }
}
</script>
