import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('./views/ListPokemons.vue')
    },
    {
      path: '/pokemons/:id',
      name: 'Pokemon',
      component: () => import('./views/CheckPokemon.vue')
    },
    {
      path: '/abilities/:id',
      name: 'Ability',
      component: () => import('./views/CheckAbility.vue')
    },
    {
      path: '/moves/:name',
      name: 'Move',
      component: () => import('./views/CheckMove.vue')
    },
    {
      path: '/area/:name',
      name: 'Area',
      component: () => import('./views/CheckArea.vue')
    },
    {
      path: '/region/:name',
      name: 'Region',
      component: () => import('./views/CheckRegion.vue')
    },
    {
      path: '/moves',
      name: 'Moves',
      component: () => import('./views/ListMoves.vue')
    },
    {
      path: '/type/:name',
      name: 'Type',
      component: () => import('./views/CheckType.vue')
    }
  ]
})
