<template>
    <v-container>
      <h1>Pokédex Redux</h1>
      <h3>The original Pokédex. Reimagined</h3>
      <v-btn href="/" color="secondary" dark>All Pokémons</v-btn>
      <v-btn href="/moves" color="secondary" dark>All Moves</v-btn>
      <v-btn @click="goToRandomPokemon()" color="secondary" dark>Random Pokémon</v-btn>
    </v-container>
</template>

<script>
export default {
  methods: {
    goToRandomPokemon: function () {
      this.$router.push('/pokemons/' + Math.floor((Math.random() * 807) + 1))
    }
  }
}
</script>

<style>

</style>
