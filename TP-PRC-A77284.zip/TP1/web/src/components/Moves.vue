<template>
  <v-container>
  <h1>All Moves:</h1>
    <template >
      <v-data-table
            :headers="headers"
            :items="pokemons"
            class="elevation-1"
        >
            <template v-slot:no-data>
                <v-alert :value="true" color="error" icon="warning">
                    Was not able to list Moves...
                </v-alert>
            </template>

            <template v-slot:items="props">
              <tr @click="selectMove(props.item)">
                <td class="subheading">{{props.item.name.value}}</td>
                <td class="subheading">{{props.item.n.value}}</td>
                <td class="subheading">
                  <v-img
                      class="white--text"
                      :src="props.item.statusLink"
                      aspect-ratio="12"
                      height="10px"
                      width="20px"
                    ></v-img>
                </td>
                <td class="subheading">{{props.item.typeName.value}}</td>
              </tr>
            </template>
        </v-data-table>
    </template>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000/moves'

export default {
  data: () => ({
    headers: [
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' },
      { text: 'Learnt by #', align: 'left', sortable: true, value: 'n.value', class: 'title' },
      { text: 'Type', align: 'left', sortable: true, value: 'typeName.value', class: 'title' },
      { text: 'Typing', align: 'left', sortable: true, value: 'atype.value', class: 'title' }
    ],
    pokemons: []
  }),

  mounted: async function () {
    try {
      var response = await axios.get(lhost)
      this.pokemons = response.data.results.bindings
      this.pokemons.forEach(e => {
        e.statusLink = 'https://img.pokemondb.net/images/icons/' + e.atype.value + '.png'
      })
    } catch (e) {
      console.log(e)
      return (e)
    }
  },
  methods: {
    selectMove: function (item) {
      this.$router.push('/moves/' + item.name.value)
    }
  }
}
</script>
