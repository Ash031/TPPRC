<template>
  <v-container grid-list-md text-xs-center>
    <h1>{{ this.areaName }}:</h1>
    <h2>Aditional Info:</h2>
    <p>Map Location Name: {{ this.area.locName.value }}</p>
    <p>Region: {{ this.area.reg.value }}</p>
  </v-container>
</template>

<script>
var axios = require('axios')
const lhost = 'http://localhost:3000/area/'
export default {
  props: ['areaName'],
  data: () => ({
    area: {}
  }),
  mounted: async function () {
    try {
      console.log(this.areaName)
      var response = await axios.get(lhost + this.areaName)
      this.area = response.data.results.bindings[0]
      if (!this.area.locName) this.area.locName = { value: 'Unkown' }
      if (!this.area.reg) this.area.reg = { value: 'Unkown' }
    } catch (e) {
      return (e)
    }
  }
}
</script>
