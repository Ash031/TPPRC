<template>
  <v-container grid-list-md text-xs-center>
    <v-layout row wrap>
      <v-flex xs6>
        <h1>{{this.pokemon.name.value}}</h1>
        <h2>Stats:</h2>
        <h4>HP: {{this.pokemon.hp.value}}</h4>
        <h4>Attack: {{this.pokemon.a.value}}</h4>
        <h4>Defense: {{this.pokemon.d.value}}</h4>
        <h4>Special Attack: {{this.pokemon.sa.value}}</h4>
        <h4>Special Defense: {{this.pokemon.sd .value}}</h4>
        <h4>Speed: {{this.pokemon.speed.value}}</h4>
        <h4 @click="selectType(pokemon.nameType1.value)">Type: {{this.pokemon.nameType1.value}}</h4>
        <h4 @click="selectType2(pokemon.nameType2Direct)">{{this.pokemon.nameType2.value}}</h4>
        <h2>Other:</h2>
        <h4>Height: {{this.pokemon.height.value}} Feet</h4>
        <h4>Weight: {{this.pokemon.weight.value}} Pounds</h4>
      </v-flex>
      <v-flex xs6>
        <v-img
          :src="this.pokemon.link"
          max-height="500px"
          max-width="500px"
        ></v-img>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
var axios = require('axios')
const lhost = 'http://localhost:3000/pokemons/'
export default {
  props: ['idPoke'],
  data: () => ({
    pokemon: {}
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.idPoke)
      this.pokemon = response.data.results.bindings[0]
      this.pokemon.link = 'https://img.pokemondb.net/artwork/vector/' + this.pokemon.name.value.toLowerCase() + '.png'
      if (this.pokemon.nameType2 === undefined) this.pokemon.nameType2 = { value: '' }
      else {
        this.pokemon.nameType2Direct = this.pokemon.nameType2.value
        this.pokemon.nameType2 = { value: 'Type: ' + this.pokemon.nameType2.value }
      }
    } catch (e) {
      return (e)
    }
  },
  methods: {
    selectType: function (type) {
      this.$router.push('/type/' + type)
    },
    selectType2: function (type) {
      if (type) this.$router.push('/type/' + type)
    }
  }
}
</script>
