<template>
    <v-container>
      <h1>{{ this.typeName }} Pokémons:</h1>
      <v-data-table :headers="PokeHeaders" :items="pokemons" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="error" icon="error">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectPokemon(props.item)"><td class="subheading">{{props.item.id.value}}</td><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
      <h1>{{ this.typeName }} Matchups:</h1>
      <h2>Double Damage To:</h2>
      <v-data-table :headers="headers" :items="doubleTo" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="info" icon="info">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectType(props.item)"><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
      <h2>Double Damage From:</h2>
      <v-data-table :headers="headers" :items="doubleFrom" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="info" icon="info">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectType(props.item)"><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
      <h2>Half Damage To:</h2>
      <v-data-table :headers="headers" :items="halfTo" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="info" icon="info">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectType(props.item)"><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
      <h2>Half Damage From:</h2>
      <v-data-table :headers="headers" :items="halfFrom" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="info" icon="info">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectType(props.item)"><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
      <h2>No Damage To:</h2>
      <v-data-table :headers="headers" :items="noDamageTo" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="info" icon="info">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectType(props.item)"><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
      <h2>No Damage From:</h2>
      <v-data-table :headers="headers" :items="noDamageFrom" class="elevation-1">
        <template v-slot:no-data><v-alert :value="true" color="info" icon="info">No Types Found</v-alert></template>
        <template v-slot:items="props"><tr @click="selectType(props.item)"><td class="subheading">{{props.item.name.value}}</td></tr></template>
      </v-data-table>
    </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000/types/'

export default {
  props: ['typeName'],
  data: () => ({
    doubleTo: [],
    halfTo: [],
    noDamageTo: [],
    doubleFrom: [],
    halfFrom: [],
    noDamageFrom: [],
    pokemons: [],
    pokemons: [],
    headers: [
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' }
    ],
    PokeHeaders: [
      { text: '#Dex', align: 'left', sortable: true, value: 'id.value', class: 'title' },
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' }
    ]
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + 'doubleto/' + this.typeName)
      this.doubleTo = response.data.results.bindings
      var response = await axios.get(lhost + 'doublefrom/' + this.typeName)
      this.doubleFrom = response.data.results.bindings
      var response = await axios.get(lhost + 'halfto/' + this.typeName)
      this.halfTo = response.data.results.bindings
      var response = await axios.get(lhost + 'halfFrom/' + this.typeName)
      this.halfFrom = response.data.results.bindings
      var response = await axios.get(lhost + 'imuneTo/' + this.typeName)
      this.noDamageTo = response.data.results.bindings
      var response = await axios.get(lhost + 'imuneFrom/' + this.typeName)
      this.noDamageFrom = response.data.results.bindings  
      var response = await axios.get(lhost + 'pokemons/' + this.typeName)
      this.pokemons = response.data.results.bindings  
    } catch (e) {
      console.log(e)
      return (e)
    }
  },
  methods: {
    selectType: function (item) {
      this.$router.push('/type/' + item.name.value)
      this.$router.go()
    },
    selectPokemon: function (item) {
      this.$router.push('/pokemons/' + item.id.value)
    }
  }
}
</script>
