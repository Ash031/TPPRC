<template>
    <v-container>
        <h1>{{this.ability.name.value}}</h1>
        <h4>Effect: {{this.ability.eff.value}}</h4>
        <h4>Generation Added: {{this.ability.gen.value}}</h4>
    </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000/abilities/'

export default {
  props: ['idAb'],
  data: () => ({
    ability: {}
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.idAb)
      this.ability = response.data.results.bindings[0]
    } catch (e) {
      return (e)
    }
  }
}
</script>
