<template>
  <v-container>
  <h1>Welcome to Pokedex Redux</h1>
    <template >
      <v-data-table
            :headers="headers"
            :items="pokemons"
            class="elevation-1"
        >
            <template v-slot:no-data>
                <v-alert :value="true" color="error" icon="warning">
                    Was not able to list Pokémons...
                </v-alert>
            </template>

            <template v-slot:items="props">
                  <v-card @click="selectPokemon(props.item)">
                    <v-img
                      class="white--text"
                      height="200px"
                      :src="props.item.img"
                    >
                      <v-container fill-height fluid>
                        <v-layout fill-height>
                        </v-layout>
                      </v-container>
                    </v-img>
                    <v-card-title>
                      <div>
                        <h1 style="color:black">{{ props.item.name.value }}</h1>
                      </div>
                    </v-card-title>
                  </v-card>
            </template>
        </v-data-table>
    </template>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000'

export default {
  data: () => ({
    headers: [
      { text: 'Pokémon', align: 'left', sortable: false, value: 'id.value', class: 'title' },
      { text: 'Dex#', align: 'left', sortable: true, value: 'id.value', class: 'title' },
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' },
      { text: 'Typing', align: 'left', sortable: true, value: 'type.value', class: 'title' }
    ],
    pokemons: []
  }),

  mounted: async function () {
    try {
      var response = await axios.get(lhost + '/pokemons')
      console.log(response.data.results.bindings)
      this.pokemons = response.data.results.bindings
      this.pokemons.forEach(e => {
        if (e.type2) e.type.value += '/' + e.type2.value
        e.img = 'https://img.pokemondb.net/artwork/vector/' + e.name.value.toLowerCase() + '.png'
      })
    } catch (e) {
      console.log(e)
      return (e)
    }
  },
  methods: {
    selectPokemon: function (item) {
      console.log(1)
      this.$router.push('/pokemons/' + item.id.value)
    }
  }
}
</script>
