<template>
    <v-container>
      <h1>{{ this.regionName }}</h1>
      <h2>Pókemons roaming this region:</h2>
      <v-data-table
        :headers="headers"
        :items="pokemons"
        class="elevation-1"
      >
        <template v-slot:no-data>
          <v-alert :value="true" color="error" icon="warning">
            Was not able to list Pokémons...
          </v-alert>
        </template>
        <template v-slot:items="props">
          <tr @click="selectPokemon(props.item)">
            <td class="subheading">{{props.item.id.value}}</td>
            <td class="subheading">{{props.item.name.value}}</td>
          </tr>
        </template>
      </v-data-table>
    </v-container>
</template>

<script>
var axios = require('axios')
const lhost = 'http://localhost:3000/region/pokemons/'

export default {
  props: ['regionName'],

  data: () => ({
    pokemons: [],
    headers: [
      { text: '#Dex', align: 'left', sortable: true, value: 'id.value', class: 'title' },
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' }
    ]
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.regionName)
      this.pokemons = response.data.results.bindings
    } catch (e) {
      return (e)
    }
  },
  methods: {
    selectPokemon: function (item) {
      this.$router.push('/pokemons/' + item.id.value)
    }
  }
}
</script>
