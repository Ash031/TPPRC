<template>
<v-container>
  <h2>Moves that can be taught to this pokémon</h2>
  <v-data-table
    :headers="headers"
    :items="moves"
    class="elevation-1"
  >
    <template v-slot:no-data>
      <v-alert :value="true" color="error" icon="warning">
        Was not able to list Pokémon Moves...
      </v-alert>
    </template>
    <template v-slot:items="props">
      <tr @click="selectMove(props.item)">
        <td class="subheading">{{props.item.name.value}}</td>
        <td class="subheading">{{props.item.power.value}}</td>
        <td class="subheading">
          <v-img
              class="white--text"
              :src="props.item.statusLink"
              aspect-ratio="12"
              height="10px"
              width="20px"
            ></v-img>
        </td>
        <td class="subheading">{{props.item.typeName.value}}</td>
      </tr>
    </template>
  </v-data-table>
</v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000/moves/pokemon/'

export default {
  props: ['idPoke'],
  data: () => ({
    moves: [],
    headers: [
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' },
      { text: 'Power', align: 'left', sortable: true, value: 'power.value', class: 'title' },
      { text: 'Attack Type', align: 'left', sortable: true, value: 'at.value', class: 'title' },
      { text: 'Typing', align: 'left', sortable: true, value: 'typeName.value', class: 'title' }
    ]
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.idPoke)
      this.moves = response.data.results.bindings
      this.moves.forEach(e => {
        if (e.power === undefined) e.power = { value: '' }
        e.statusLink = 'https://img.pokemondb.net/images/icons/' + e.at.value + '.png'
      })
    } catch (e) {
      return (e)
    }
  },
  methods: {
    selectMove: function (item) {
      this.$router.push('/moves/' + item.name.value)
    }
  }
}
</script>

<style>

</style>
