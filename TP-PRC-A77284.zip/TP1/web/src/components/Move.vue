<template>
 <v-container>
     <h1>{{ this.moveName }}</h1>
     <h4>Power: {{ this.move.power.value }}</h4>
     <h4>Accuracy: {{ this.move.acc.value }}</h4>
     <h4>Attack Type: {{ this.move.at.value }}</h4>
     <h4>Attack Typing: {{ this.move.typeName.value }}</h4>
     <h4>Generation Added: {{ this.move.gen.value }}</h4>
     <h4>Chance to Afflict bonus effect: {{ this.move.chance.value }}</h4>
 </v-container>
</template>

<script>
var axios = require('axios')
const lhost = 'http://localhost:3000/moves/'
export default {
  props: ['moveName'],
  data: () => ({
    move: {}
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.moveName)
      this.move = response.data.results.bindings[0]
      if (this.move.power === undefined) this.move.power = { value: '-' }
      if (this.move.acc === undefined) this.move.acc = { value: '-' }
      if (this.move.chance === undefined) this.move.chance = { value: '0' }
      this.move.chance.value += '%'
    } catch (e) {
      return (e)
    }
  }
}
</script>
