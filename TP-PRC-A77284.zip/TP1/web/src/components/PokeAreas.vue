<template>
  <v-container>
    <h2>This pokémon appears on:</h2>
    <v-data-table
    :headers="headers"
    :items="areas"
    class="elevation-1"
  >
    <template v-slot:no-data>
      <v-alert :value="true" color="error" icon="warning">
        Was not able to list Pokémon Areas, ...
      </v-alert>
    </template>
    <template v-slot:items="props">
      <tr @click="selectMove(props.item)">
        <td @click="selectArea(props.item)" class="subheading">{{props.item.name.value}}</td>
        <td @click="selectRegion(props.item)" class="subheading">{{props.item.reg.value}}</td>
      </tr>
    </template>
  </v-data-table>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000/pokemons/area/'

export default {
  props: ['idPoke'],
  data: () => ({
    areas: [],
    headers: [
      { text: 'Name', align: 'left', sortable: true, value: 'name.value', class: 'title' },
      { text: 'Region', align: 'left', sortable: true, value: 'reg.value', class: 'title' }
    ]
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.idPoke)
      this.areas = response.data.results.bindings
    } catch (e) {
      return (e)
    }
  },
  methods: {
    selectArea: function (item) {
      this.$router.push('/area/' + item.name.value)
    },
    selectRegion: function (item) {
      this.$router.push('/region/' + item.reg.value)
    }
  }
}
</script>

<style>

</style>
