<template>
    <v-container>
      <h1>{{ this.regionName }}</h1>
      <h2>Games featuring this region:</h2>
      <v-data-table
        :headers="headers"
        :items="games"
        class="elevation-1"
      >
        <template v-slot:no-data>
          <v-alert :value="true" color="error" icon="warning">
            Was not able to list Games...
          </v-alert>
        </template>
        <template v-slot:items="props">
          <tr>
            <td class="subheading">{{props.item.name.value}}</td>
          </tr>
        </template>
      </v-data-table>
    </v-container>
</template>

<script>
var axios = require('axios')
const lhost = 'http://localhost:3000/region/'

export default {
  props: ['regionName'],

  data: () => ({
    games: [],
    headers: [
      { text: 'Name', align: 'center', sortable: true, value: 'name.value', class: 'title' }
    ]
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.regionName)
      this.games = response.data.results.bindings
    } catch (e) {
      return (e)
    }
  }
}
</script>
