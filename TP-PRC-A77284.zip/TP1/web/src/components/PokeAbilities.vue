<template>
  <v-container>
    <h1>Abilities:</h1>
    <template v-for="(ability,index) in this.abilities">
      <v-btn @click="selectAbility(ability)" color="blue">{{ ability.name.value }}</v-btn>
    </template>
  </v-container>
</template>

<script>
import axios from 'axios'
const lhost = 'http://localhost:3000/abilities/pokemon/'

export default {
  props: ['idPoke'],
  data: () => ({
    abilities: []
  }),
  mounted: async function () {
    try {
      var response = await axios.get(lhost + this.idPoke)
      this.abilities = response.data.results.bindings
    } catch (e) {
      return (e)
    }
  },
  methods: {
    selectAbility: function (item) {
      this.$router.push('/abilities/' + item.id.value)
    }
  }
}
</script>

<style>

</style>
