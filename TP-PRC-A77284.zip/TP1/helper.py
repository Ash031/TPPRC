#!/usr/bin/python3

import subprocess
from os import listdir
subprocess.run("mkdir DB",shell=True)
for i in range(1,808):
    subprocess.run("wget -qO - https://pokeapi.co/api/v2/pokemon/"+str(i)+" >DB/#"+str(i)+".json",shell=True)
    
string = "["
string += ",\n".join([open("./DB/"+f).read() for f in listdir("./DB/")]) +"]"
file = open("JSONS/Pokedex.json","w+")
file.write(string)
file.close()